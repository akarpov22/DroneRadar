import { MutationResolvers } from "../../generated/schema";
import { registerDroneIfNotExists } from '../mutations/register-drone-If-not-exists'
import { registerDrone } from '../mutations/register-drone'
import { appendPosition } from '../mutations/append-position'
import { assignOperator } from "../mutations/assign-operator";
import { assignModel } from "../mutations/assign-model";
import { endSession } from "../mutations/end-seesion";
import { createSession } from "../mutations/create-session";
import { createOperator } from "../mutations/create-operator";
import { createRegion } from "../mutations/create-region";
import { createDroneModel } from "../mutations/create-drone-model";
import { createUserZone } from "../mutations/create-user-zone";
import { updateUserZone } from "../mutations/update-user-zone";
import { deleteUserZone } from "../mutations/delete-user-zone";
import { unlinkDrone } from "../mutations/unlink-drone";
import { updateUserRole } from "../mutations/update-user-role";
import { deleteUser } from "../mutations/delete-user";

import { deactivateDroneModel } from "../mutations/deactivate-drone-model";
import { deactivateRegion } from "../mutations/deactivate-region";

export const mutationResolvers: MutationResolvers = {
    registerDrone,
    registerDroneIfNotExists,
    appendPosition,
    assignOperator,
    assignModel,
    endSession,
    createSession,
    createOperator,
    createRegion,
    createDroneModel,
    createUserZone,
    updateUserZone,
    deleteUserZone,
    unlinkDrone,
    updateUserRole,
    deleteUser,
    deactivateDroneModel,
    deactivateRegion,
}